package threadExample;

public class threadExmple extends Thread{
	
	public static void main(String[] args) {
		
		Hi t1 = new Hi();
		Hello t2 = new Hello();
		world t3 = new world();		
		
		t1.setName("Hi Thread");  
		t2.setName("Hello Thread");
		t3.setName("World Thread");	
		
		t2.setPriority(Thread.MAX_PRIORITY);
		t3.setPriority(Thread.NORM_PRIORITY);
		t1.setPriority(Thread.MIN_PRIORITY);		
		
		t1.start();
		t2.start();
		t3.start();	
	}
}

class Hi extends Thread
{
	public void thread(){
		
		System.out.println("Hai, I am HI classs");
		System.out.println(Thread.currentThread().getPriority());
	}
	
	
}

class Hello extends Thread
{
	public void thread(){
		
		System.out.println("Hello, I am Hello class");
		System.out.println(Thread.currentThread().getPriority());
	}
	
	
}

class world extends Thread
{
	public void thread(){
		
		System.out.println("Welcome java world");
		System.out.println(Thread.currentThread().getPriority());
	}
	
	
}